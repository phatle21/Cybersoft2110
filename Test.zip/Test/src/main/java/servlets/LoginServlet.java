package servlets;

import dtos.LoginDto;
import services.LoginService;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;

@WebServlet(name = "loginPage", urlPatterns = "/login")
public class LoginServlet extends HttpServlet {
    private LoginService loginService = null;
    public LoginServlet(){
        loginService = new LoginService();
    }
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("UTF-8");
        resp.setCharacterEncoding("UTF-8");
        req.getRequestDispatcher("index.jsp").forward(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("UTF-8");
        resp.setCharacterEncoding("UTF-8");
        String email = req.getParameter("email");
        String password = req.getParameter("password");
        LoginDto loginDto = new LoginDto(email, password);
        boolean isLogin = loginService.checkLogin(email, password);
        int result = isLogin ? 1 : 0;
        if(result > 0){
            HttpSession session = req.getSession();
            session.setAttribute("LOGIN_USER",loginDto);
            session.setMaxInactiveInterval(1800);
            resp.sendRedirect(req.getContextPath() + "/home");
        }else{
            req.setAttribute("message","Sai tên đăng nhập hoặc mật khẩu");
            req.setAttribute("login", loginDto);
            req.getRequestDispatcher("index.jsp").forward(req, resp);
        }
    }
}
