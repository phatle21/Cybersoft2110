package services;

import daos.LoginDao;
import dtos.LoginDto;

import java.util.List;

public class LoginService {
    LoginDao loginDAO = new LoginDao();

    public boolean checkLogin(String email, String password){
        List<LoginDto> list = loginDAO.getUserByEmailAndPassword(email, password);
        for(LoginDto usersModel : list){
            System.out.println(usersModel.getEmail());
        }
        if(list.size() > 0){
            // đăng nhập thành công
            return true;
        }else{
            // đăng nhập thất bại
            return false;
        }
    }
}
