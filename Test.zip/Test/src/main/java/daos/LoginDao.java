package daos;

import dtos.LoginDto;
import utils.LoginUtil;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class LoginDao {

    public List<LoginDto> getUserByEmailAndPassword(String email, String password){
        List<LoginDto> list = new ArrayList<>();
        try {
            String query = "select * from users u where u.email = ? and u.password = ?";
            Connection connection = LoginUtil.getConnection();
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1, email);
            preparedStatement.setString(2, password);
            ResultSet resultSet = preparedStatement.executeQuery(); // đưa ra 1 mảng
            while (resultSet.next()) {
                LoginDto loginDTO = new LoginDto();
                loginDTO.setEmail(resultSet.getString("email"));
                loginDTO.setPassword(resultSet.getString("password"));
                list.add(loginDTO);
            }
            connection.close();

        } catch (Exception e) {
            System.out.println("Error getUsersByEmailAndPassword" + e.getMessage());
        }
        return list;
    }
}




